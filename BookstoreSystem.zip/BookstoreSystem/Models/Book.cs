﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace ConsoleApp1.Models
{
    #region Part 1 
    //Q1: Why did the property Id become a Primary Key without any explicit configuration?

    //Because Entity Framework Core uses conventions. It automatically recognizes a property named Id(or < EntityName > Id) as the Primary Key of the entity, so no explicit configuration is required.

    //Q2: Why is Country nullable in the database while Price is not?

    //Because Country is defined as a nullable string(string ?), so EF Core allows it to contain NULL in the database.
    //Price is defined as a non - nullable value type(decimal), so it cannot contain NULL and is created as a required column in the database.

    #endregion
    internal class Book
    {
        public int Id { get; set; }
       
        public string Title { get; set; }
     
        public decimal Price { get; set; }
        public DateTime? PublishedDate { get; set; }
    }

    #region lastQ
    //1. Why do we use Code First rather than Database First?

        //Code First allows developers to define the database structure using C# classes and Entity Framework Core. The database is then created and updated using migrations
        //It is useful because it keeps the C# code as the main source of truth, makes database changes easier to manage through migrations, and allows developers to focus on the application model without manually creating the database first.

    //2. Why do we use Fluent API over Data Annotations?

        //Fluent API provides more flexibility and control when configuring entities and their relationships.It keeps database configuration separate from the entity classes, which makes the classes cleaner and easier to maintain.
        //It is especially useful for complex configurations that cannot be easily expressed using Data Annotations.
    #endregion
}
